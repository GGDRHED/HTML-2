from django.shortcuts import render
from random import randint

def lottery(request):
    numbers = [randint(1, 9) for _ in range(3)]
    context = {
        'numbers': numbers,
        'result': 'Победа' if len(set(numbers)) == 1 else 'Джекпот' if len(set(numbers)) == 3 else 'Поражение'
    }
    return render(request, 'lottery.html', context)

def greeting(request):
    name = "John Doe"
    return render(request, 'greeting.html', {'name': name})

# Create your views here.
